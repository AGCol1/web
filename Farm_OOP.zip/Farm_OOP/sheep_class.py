from animal_class import * 

class Sheep(Animal):
    """A sheep animal"""

    def __init__(self, name="Unnamed"):
        super().__init__(1, 3, 6)
        self._type = "Sheep"
        self._name = name  # Add a name attribute

    def grow(self, food, water):
        if food >= self._food_need and water >= self._water_need:
            if self._status == "Seedling" and water > self._water_need:
                self._growth += self._growth_rate * 1.5
            elif self._status == "Young" and water > self._water_need:
                self._growth += self._growth_rate * 1.25
            else: 
                self._growth += self._growth_rate
        self._days_growing += 1 
        self._update_status()

    def report(self):
        """Extend the report to include the name."""
        base_report = super().report()
        return f"Name: {self._name}, {base_report}"

def main():
    sheep_crop = Sheep("Shaun")  # Provide a name
    print(sheep_crop.report())
    manual_grow(sheep_crop)
    print(sheep_crop.report())
    manual_grow(sheep_crop)
    print(sheep_crop.report())

if __name__ == "__main__":
    main()
